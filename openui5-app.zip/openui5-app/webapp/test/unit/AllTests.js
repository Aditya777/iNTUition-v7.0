sap.ui.define([
	"./model/formatter",
	"./controller/App"
], function() {
	"use strict";
});
