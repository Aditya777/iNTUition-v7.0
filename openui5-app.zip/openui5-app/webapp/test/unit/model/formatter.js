/*global QUnit*/

sap.ui.define([
	"sap/ui/demo/basicTemplate/model/formatter"
], function() {
	"use strict";

	QUnit.module("Formatters");

	QUnit.test("I should test my formatters", function (assert) {
		assert.ok(true);
	});

});
