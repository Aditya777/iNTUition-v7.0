from keras.models import Sequential
from keras.layers import Dense
import numpy as np


class DeployModel():
    def makePrediction(self, Age, Vaccine, Sex, Other_Medicine, Current_Illness, History, Birth_Defect, Allergies):
        w = np.load('test.npy', allow_pickle=True)
        print(w)
        self.model = Sequential()
        self.model.add(Dense(20, input_dim=8,
                             kernel_initializer='he_uniform', activation='relu'))
        self.model.add(Dense(5, activation='sigmoid'))
        self.model.compile(loss='categorical_crossentropy', optimizer='adam')
        #arr = w.split(",")
        #arr2 = []
        #arr2.append(int(i) for i in arr)
        #arr = np.array(arr2)
        self.model.set_weights(w)
        input = [Age, Vaccine, Sex, Other_Medicine,
                 Current_Illness, History, Birth_Defect, Allergies]
        nX = np.asarray([input])
        out = self.model.predict(nX)
        s = ""
        for result in out:
            res = result
        for outs in res:
            s += str(outs)
            s += ","
        return s
