from typing import get_type_hints
from flask import Flask, request
from flask_restplus import Api, Resource, fields
from main import DeployModel

app = Flask(__name__)

api = Api(app, version="1.0",
          title="iNTUition Hackathon",
          doc='/docs')

# Namespaces
ns_ins_del = api.namespace(
    'package', description='Insert and Withdraw Packages')

model = DeployModel()


@ns_ins_del.route('/predict')
class Insert(Resource):
    def get(self):
        Age = request.args.get('age')
        Vaccine = request.args.get('vaccine')
        Sex = request.args.get('sex')
        Current_Illness = request.args.get('cur_illness')
        Allergies = request.args.get('allergies')
        Other_Medicine = 0
        History = 0
        Birth_Defect = 0

        print(Age, Vaccine, Sex, Current_Illness, Allergies)

        action = model.makePrediction(Age, Vaccine, Sex, Other_Medicine,
                                      Current_Illness, History, Birth_Defect, Allergies)

        return {'prediction': action}


if __name__ == '__main__':
    app.run()
