sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../model/formatter",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(Controller, formatter, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("sap.ui.demo.basicTemplate.controller.App", {

		formatter: formatter,

		onInit: function () {
			var view = this.getView();
			var predictionForm = this.getView().byId("predictionForm");
			var predictionBtn = this.getView().byId("predictFormButton");
			if(predictionForm.getVisible()) {
				predictionForm.setVisible(false);
			}
			if(predictionBtn.getVisible()) {
				predictionBtn.setVisible(false);
			}
		},

		onPress: async function() {
			var view = this.getView();
			view.setBusy(true);
			await new Promise(r => setTimeout(r, 5000));
			// Save data in Cache

			view.setBusy(false);
			MessageBox.success("Your data has been anonymized and submitted for crowdsourcing. Thank you!");
		},

		onPredict: async function() {
			var view = this.getView();
			view.setBusy(true);
			var sex = this.getView().byId("sex").getSelectedButton().getText();
			var age = this.getView().byId("age_predict").getValue();
			var type_vaccine = this.getView().byId("typeVaccinePredict").getSelectedButton().getText();
			var conditions = this.getView().byId("conditions").getSelectedItems();
			var allergies = this.getView().byId("allergies").getSelectedItems();

			var vaccine;
			if(type_vaccine == "Pfizer-BioNTech") vaccine = 1; else vaccine = 0

			var sex_form;
			if(sex == "Male") sex_form = 0; else sex_form = 1 

			var conditions_form;
			if(conditions.length == 0) conditions_form = 0; else conditions_form = 1

			view.setBusy(false);
			MessageBox.success("Most probable Side-Effects based on your details", {
				title: "Side-Effects",
				id: "messageBoxId2",
				details: "<p><strong>These can happen:</strong></p>\n" +
					"<ul>" +
					"<li>Headache</li>" +
					"<li>Body Aches</li>" +
					"</ul>" +
					"<p>Get more help <a href='https://www.cdc.gov/coronavirus/2019-ncov/vaccines/expect/after.html' target='_top'>here</a>.",
				contentWidth: "100px"
			});


			var requestOptions = {
				method: 'GET',
				redirect: 'follow'
			  };
			  
			  fetch("https://myfirstapp-reflective-duiker-kw.cfapps.us10.hana.ondemand.com/", requestOptions)
				.then(response => response.text())
				.then(result => console.log(result))
				.catch(error => console.log('error', error));

			var requestOptions = {
					method: 'GET',
					redirect: 'follow'
				  };
				  
			var url = "http://127.0.0.1:5000/package/predict?age=" + age + "&vaccine=" + vaccine + "&sex=" + sex_form + "&cur_illness=" + conditions_form + "&allergies=0", requestOptions;
			
			console.log(url)

			   fetch(url)
					.then(response => response.text())
					.then(result => MessageToast.show(result))
					.catch(error => console.log('error', error));

		},

		press_prediction: function() {
			var predictionForm = this.getView().byId("predictionForm");
			var predictionBtn = this.getView().byId("predictFormButton");
			var submitForm = this.getView().byId("submissionForm");
			var submitBtn = this.getView().byId("submissionFormButton");
			if(!predictionForm.getVisible()) {
				predictionForm.setVisible(true);
			}
			if(!predictionBtn.getVisible()) {
				predictionBtn.setVisible(true);
			}
			if(submitForm.getVisible()) {
				submitForm.setVisible(false);
			}
			if(submitBtn.getVisible()) {
				submitBtn.setVisible(false);
			}
		},

		press_submitData: function() {
			var predictionForm = this.getView().byId("predictionForm");
			var predictionBtn = this.getView().byId("predictFormButton");
			var submitForm = this.getView().byId("submissionForm");
			var submitBtn = this.getView().byId("submissionFormButton");
			if(predictionForm.getVisible()) {
				predictionForm.setVisible(false);
			}
			if(predictionBtn.getVisible()) {
				predictionBtn.setVisible(false);
			}
			if(!submitForm.getVisible()) {
				submitForm.setVisible(true);
			}
			if(!submitBtn.getVisible()) {
				submitBtn.setVisible(true);
			}
		},

		press_analysis: function() {
			window.open("https://ourworldindata.org/covid-vaccinations");
		},

		press_stats: function(oEvent)
			{
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("second");
			},
			
		runModel: function() {

			var requestOptions = {
				method: 'GET',
				redirect: 'follow'
			  };
			  
			  fetch("https://myfirstapp-reflective-duiker-kw.cfapps.us10.hana.ondemand.com/", requestOptions)
				.then(response => response.text())
				.then(result => MessageToast.show(result))
				.catch(error => console.log('error', error));

			var requestOptions = {
					method: 'GET',
					redirect: 'follow'
				  };
				  
			   fetch("http://127.0.0.1:5000/package/predict/3", requestOptions)
					.then(response => response.text())
					.then(result => MessageToast.show(result))
					.catch(error => console.log('error', error));

		},

		callbackFunc: function(response) {
			MessageToast.show(response);
		}

	});
});